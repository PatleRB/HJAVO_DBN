import random,math
import numpy as np

def algm(N):
    def generate(n, m, l, u): # Vulture position
        data = []           # create a empty array
        for i in range(n):
            tem = []
            for j in range(m):
                tem.append(random.uniform(l, u))   # append the value to temp
            data.append(tem)   # append the value to data
        return data

    M, lb, ub = 5, 1, 5
    g, max = 0, 100

    soln = generate(N, M, lb, ub) # call the function


    def fitness(soln):
        F = []
        for i in range(len(soln)):
            F.append(random.random()) #create a random number append to f
        return F
    gBest, gfit = [], float('inf')
    #phase 1
    def grouping(x):    #grouping vulture based on best solution
        sum=[]
        for i in range(len(x)):
           sum+=x[i]
        P = (fit[i]/(sum[i]*fit[i]))
        L1 = random.uniform(0,1)
        Best_Vulture =[]
        if P == L1 :
            Best_Vulture.append(pBest)
        else:
            Best_Vulture.append(pBest)
        return Best_Vulture


    #phase2
    def hunger_degree(t,T):
        r = random.uniform(0,1)
        z = random.uniform(-1,1)
        h = random.uniform(-2,2)
        gt = h*(math.sin((np.pi/2)*(t/T))+math.cos((np.pi/2)*(t/T))-1)
        Fi = (2*r+1)*z*(1-(t/T))+gt
        return Fi

    #phase_3
    def exploration_stage(R,X,f):
        Exp_stage=[]
        p1 = random.uniform(0,1)
        rp1 = random.uniform(0,1)
        ri2 = random.uniform(0,1)
        ri3 = random.uniform(0,1)
        C = random.uniform(0,2)
        beta_1 = 0.9
        theta_0 = 0  # initialize the vector
        m_t = 0
        v_t = 0
        epsilon = 1e-8
        def grad_func(x):  # calculates the gradient
            return 2 * x - 4
        g_t = grad_func(theta_0)
        m_t = beta_1 * m_t + (1 - beta_1) * g_t
        alpha=0.001
        r1=random.random()
        r2=random.random()
        for i in range(len(R)):
            for j in range(len(R[i])):
                D = np.abs(C *np.array(R[i][j]) -X)  # Distance
                if p1 >= rp1:
                    ############# proposed update equation #################
                    Exp_stage.append((R[i][j]*(1+X[i][j]*f)*(1-r1+r2)-((r2*pWrst[i]-r1*pBest[i])*f))/(1-r1+r2+f))
                elif p1 < rp1:
                    Exp_stage.append(np.array(R[i][j])-f+ri2*((ub-lb)*ri3+lb))
        return Exp_stage, D

    #phase_4

    def position_update(R,X,D,f):        #Exploration stage medium
        p1 = random.uniform(0, 1)
        C = random.uniform(0, 2)
        alpha=0.001
        theta_0 = 0  # initialize the vector
        m_t = 0
        v_t = 0
        beta_1 = 0.9
        epsilon = 1e-8
        up_position =[]
        ri4 = random.uniform(0,1)
        def grad_func(x):  # calculates the gradient
            return 2 * x - 4
        g_t = grad_func(theta_0)
        m_t = beta_1 * m_t + (1 - beta_1) * g_t
        for i in range(len(R)):
            for j in range(len(R[i])):
                d = np.array(R[i][j]) - X[i][j]
                up_position.append(R[i][j]*(C*(f+ri4)-1)-(p1-alpha*(m_t/(np.sqrt(v_t)+epsilon))))     # Food competition
        return up_position

    def position_update_1(R,X):
        up_pos_1 =[]
        r5 =random.uniform(0,1)
        r6 =random.uniform(0,1)
        for i in range(len(R)):
            for j in range(len(R[i])):
                S1 = R[i][j]*((r5*X[i][j])/2*np.pi)*math.cos(X[i][j])
                S2 = R[i][j]*((r6*X[i][j])/2*np.pi)*math.sin(X[i][j])
                up_pos_1.append(R[i][j]-(S1+S2))
        return up_pos_1

    #phase_5
    def position_update_2(X,R):        #Exploration stage later
        upd_pos_2=[]
        for i in range(len(R)):
            for j in range(len(R[i])):
                A1 = R[i][j] -((R[i][j]*X[i][j])/(R[i][j]-np.square(X[i][j]))) * Fi   #Aggressive behaviour
        upd_pos_2.append(A1/2)
        return upd_pos_2

    def position_update_3(R,X):
        up_pos_3 =[]
        r1 = random.uniform(0,1)
        r2 = random.uniform(0,1)
        delta = 1.5
        sigma = (((1+delta)*math.sin((np.pi*delta)/2))/((1+delta)*delta*2**((delta-1)/2)))
        levi = (0.01*((r1*sigma)/np.abs(r2**(1/delta))))    #dimension
        for i in range(len(R)):
            for j in range(len(R[i])):
                d = np.array(R[i][j]) - X[i][j]
                up_pos_3.append(R[i][j]-np.abs(d)*Fi*levi)
        return up_pos_3


    while g<max:
        fit = fitness(soln)
        bst = np.argmin(fit)
        wrst = np.argmax(fit)
        pWrst = soln[bst]
        pfit, pBest = fit[bst], soln[bst]   # current best fit, solution

        Best_Vulture = grouping(soln)
        Fi = hunger_degree(g,max)
        D = exploration_stage(Best_Vulture,soln,Fi)
        position_update(Best_Vulture,soln,D,Fi)
        position_update_1(Best_Vulture,soln)
        position_update_2(soln,Best_Vulture)
        position_update_3(Best_Vulture,soln)

        g+=1

    return pfit

