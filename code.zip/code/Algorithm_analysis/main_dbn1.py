from sklearn.model_selection import train_test_split
import numpy as np
from dbn.tensorflow import SupervisedDBNClassification
from dbn import HJAVO

def main(merge,target,tr_per, A,Se,Sp):

    target=np.array(target).flatten()
    # print("lab",target)
    aa=HJAVO.algm()
    X_train, X_test, y_train, y_test = train_test_split(merge, target, train_size=tr_per)

    classifier = SupervisedDBNClassification(hidden_layers_structure=[10],
                                             learning_rate_rbm=0.2,
                                             learning_rate=0.01,
                                             n_epochs_rbm=3,
                                             n_iter_backprop=10,
                                             batch_size=500,
                                             activation_function='relu',
                                             dropout_p=0.2)

    y_train[10]=0

    classifier.fit(X_train, y_train)

    # Save the model
    classifier.save('model_dbn.pkl')
    # # Restore it
    classifier = SupervisedDBNClassification.load('model_dbn.pkl')
    # Test
    y_pred = classifier.predict(X_test)
    y_pred_1 = np.rint(y_pred)
    aa1 = aa
    unique_clas = np.unique(y_pred_1)
    target = y_test
    tp, tn, fn, fp = 0, 0, 0, 0
    uni = np.unique(target)  # unique label
    for i1 in range(len(uni)):
        c = uni[i1]
        for i in range(len(target)):
            if (target[i] == c and y_pred[i] == c):
                tp = tp + 1
            if (target[i] != c and y_pred[i] != c):
                tn = tn + 1
            if (target[i] == c and y_pred[i] != c):
                fn = fn + 1
            if (target[i] != c and y_pred[i] == c):
                fp = fp + 1

    acc_1 = (tp + tn) / (tn + tp + fn + fp)  # accuracy
    sen_1 = (tp) / (tp + fn)  # sensitivity
    spe_1 = (tn) / (tn + fp)  # specificity
    A.append(acc_1)
    Se.append(sen_1)
    Sp.append(spe_1)