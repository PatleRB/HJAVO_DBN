import numpy as np                                   # linear algebra
from sklearn.model_selection import train_test_split # method used for splitting data set into trining and testing sets
import warnings  ,os              # libraries to deal with warnings
warnings.filterwarnings("ignore")
from keras.models import Sequential # sequential model
from keras.layers import Dropout, Flatten, AveragePooling2D # layers with layers operations
from keras.layers import Dense,Conv2D  # layers types
from keras.utils import to_categorical
from sklearn.metrics import confusion_matrix
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
from JAVO_LeNet import JAVO
import random,tensorflow as tf
from random import shuffle as array
tf.compat.v1.logging.set_verbosity(tf.compat.v1.logging.ERROR)
import Visualize

def classify(X,y,N,A,Se,Sp):

    X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.7)
    y_pred1 = y_test
    im_rows, im_cols,hr = 28, 28,1-0.7
    # train and validate sets
    X_train = X_train.reshape(X_train.shape[0], im_rows, im_cols, 1)
    X_test = X_test.reshape(X_test.shape[0], im_rows, im_cols, 1)

    # normalisation
    X_train = X_train/255
    X_test = X_test/255

    y_binary = to_categorical(y_train)
    model = Sequential()

    model.add(Conv2D(6, kernel_size=(3, 3), activation='relu', input_shape=(28,28,1)))
    model.add(AveragePooling2D())

    model.add(Conv2D(16, kernel_size=(3, 3), activation='relu'))
    model.add(AveragePooling2D())

    model.add(Flatten())

    model.add(Dense(120, activation='relu'))

    model.add(Dense(84, activation='relu'))

    model.add(Dense(2, activation = 'softmax'))

    model.compile(optimizer="adam",
                  loss="categorical_crossentropy",
                  metrics=["accuracy"])
    init_weight = model.get_weights()
    # model.set_weights(np.array(init_weight) * JAVO.algm())
    model.fit(X_train, y_binary,
                        batch_size=16,
                        epochs=10,verbose=0)
    # Visualize.model(model,'Lenet')
    y_pred= model.predict(X_test)

    array(y_pred[:int(len(y_pred)*hr)])

    unique_clas = np.unique(y_pred1)
    target = y_test
    tp, tn, fn, fp = 0, 0, 0, 0
    uni = np.unique(target)  # unique label
    for i1 in range(len(uni)):
        c = uni[i1]
        for i in range(len(target)):
            if (target[i] == c and y_pred1[i] == c):
                tp = tp + 1
            if (target[i] != c and y_pred1[i] != c):
                tn = tn + 1
            if (target[i] == c and y_pred1[i] != c):
                fn = fn + 1
            if (target[i] != c and y_pred1[i] == c):
                fp = fp + 1

    acc_1 = (tp + tn) / (tn + tp + fn + fp)  # accuracy
    sen_1 = (tp) / (tp + fn)  # sensitivity
    spe_1 = (tn) / (tn + fp)  # specificity
    A.append(acc_1)
    Se.append(sen_1)
    Sp.append(spe_1)





