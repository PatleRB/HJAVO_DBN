import pandas as pd
import numpy as np
from Main import MapReducer1,MapReducer_algorithm_analysis
from Main import DFC


def read(dts):  # function  to read data
    reader = pd.read_csv('dataset.csv',header=None)  # read a file
    data = np.array(reader)
    reader1 = pd.read_csv('target.csv',header=None)  # read a file
    target = np.array(reader1)
    return data,target


def preprocess(data,dts):  # function to preprocess
    F1 = DFC.DFC_m(n_clusters=15)
    data = data.astype('float')
    F1.fit(data)
    centers = F1.centers
    idx_ctr = np.argsort(np.transpose(centers))[0]
    F1.u = F1.u[:, idx_ctr]
    labels = F1.u.argmax(axis=1)
    datanew = F1.u
    return datanew,labels

def callmain(dts, tr_ep):  # main function
    tr_ep=tr_ep/100   # change the
    acc, sen, spe = [], [], []  # create a empty array
    print("\n Reading input data..")
    data,target = read(dts)  # read the data type
    print("\n Deep Fuzzy Clustering..")
    cluster_data, cluster_label = preprocess(data, dts)  # function call
    print("\n Mapper Reducer :")
    MapReducer1.Map_Reducer(cluster_data,cluster_label,target,dts,tr_ep,acc,sen,spe)
    print("\n Please wait..")
    ########### Calling Methods ############
    Ensemble_RBM.run.rbm(cluster_data, target, tr_ep, acc, sen, spe)
    Hybrid_NBC_TFIDF.run.navie(cluster_data, target, tr_ep, acc, sen, spe)
    Adaptive_E_Bat_algorithm.dbn.classify(cluster_data, target, tr_ep, acc, sen, spe)
    acc, sen, spe= Improved_KNN.run.knn(cluster_data, target, tr_ep,dts, acc, sen, spe)
    # print(acc,sen,spe)
    return acc, sen, spe


