import random, numpy as np
import pandas as pd

'''input_data = [[1,4,7,10], [2,5,8,11], [3,6,9,12]]   # input data with 3 instances
total_instance = 10     # existing rows + extra rows to be added (output with 10 instances)
'''

def augment(data):
    ins_total = 10000

    c_min, c_max = [], []   # column min & max
    for i in range(len(data)):   # for each column
        col = np.array(data)[i]
        c_min.append(np.min(col))   # add min value
        c_max.append(np.max(col))   # add max value


    augmented_data = []
    for i in range(ins_total):
        tem = []
        for j in range(1):
            if i >= 1:
                # for extra instance generate random b/w min & max of that column
                tem.append(random.uniform(c_min[j], c_max[j]))
            else:
                tem.append(data[i])
        augmented_data.append(tem)

    return (np.array(augmented_data)).flatten()

