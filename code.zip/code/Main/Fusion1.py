import sys, numpy as np
from Main import Sort,DRN
import pandas as pd

def kumar_Hassebrook(P, Q):
    dist = (np.sum(P * Q) / (np.sum(np.square(P))) + np.sum(np.square(Q)) - np.sum(P * Q))
    return dist

def feature_fusion(data,clas,S,it):

    # arrange features by hellinger distance
    f =kumar_Hassebrook(data, clas).tolist( )
    # T = len(f)
    # F_new, l = [], round(T)

    # training data generation for Deep neural Network
    train_x, train_y = data, clas
    beta = DRN.classify(np.array(train_x), np.array(train_y), np.array(data))  # beta value prediction by Deep residual Network

    return beta,f
