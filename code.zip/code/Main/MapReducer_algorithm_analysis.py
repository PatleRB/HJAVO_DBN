import numpy as np
import pandas as pd
from sklearn import preprocessing
from Main import DRN,Fusion
import JAVO_LeNet.LeNet,Algorithm_analysis.LeNet_PSO,Algorithm_analysis.LeNet_AVO,Algorithm_analysis.LeNet_CSO, Algorithm_analysis.LeNet_jaya

def min_max_normalization(data):
    min_max_scaler = preprocessing.MinMaxScaler()
    data_minmax = min_max_scaler.fit_transform(data)
    return data_minmax


# mapper process: split the data to the size of mapper
def mapper(data, target, ms):
    feature_size = 10
    pre_processed_data,fused_data = [],[]
    for i in range(ms):
        ######### Min max Normalization ###########
        data_p = min_max_normalization(data[i])
        pre_processed_data.append(data_p)
    for i in range(ms):
        ######### Feature Fusion (Hellinger Distance ###########
        sel_feature=Fusion.feature_fusion(pre_processed_data[i],target[i],feature_size,i)
        fused_data.append(sel_feature)
    return fused_data



# Reducer process
def reducer(fused_data,target,dts,N,acc,sen,spe):
    merge = []
    for i in range(len(fused_data)):
        merge.extend(fused_data[i])
    if dts == 'covid_ml':
        np.savetxt('fused_data.csv', merge, delimiter=',',  # save the fused dataset
                 fmt='%s')
    else:
        np.savetxt('fused_data.csv', merge, delimiter=',',  # save the fused dataset
                   fmt='%s')
    print("\t\tBig data classification using JAVO.. ")
     ################Algorithm analysis################

    JAVO_LeNet.LeNet.classify(merge, target, N, acc, sen, spe)
    Algorithm_analysis.LeNet_AVO.classify(merge, target, N, acc, sen, spe)
    Algorithm_analysis.LeNet_jaya.classify(merge, target, N, acc, sen, spe)
    Algorithm_analysis.LeNet_CSO.classify(merge, target, N, acc, sen, spe)
    Algorithm_analysis.LeNet_PSO.classify(merge, target, N, acc, sen, spe)



    return merge


# Feature main
def Mapper_phase(data, target, ms):
    feature = mapper(data, target, ms)
    return feature

def Map_Reducer(feat,target,lab,dts,ls,acc,sen,spe):
    ms = len(feat)
    print("\t >>Mapper Phase")
    sel_feat = Mapper_phase(feat,target,ms)
    print("\t >>Reducer Phase")
    reducer(sel_feat,lab,dts,ls,acc,sen,spe)
    return 0









