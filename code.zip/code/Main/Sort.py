import numpy as np


def kumar_Hassebrook(P, Q):
    dist = (np.sum(P * Q) / (np.sum(np.square(P))) + np.sum(np.square(Q)) - np.sum(P * Q))
    return dist

def Hellinger_distance(p, q):
  # distance between p an d
  # p and q are np array probability distributions
  n = len(p)
  sum = 0.0
  for i in range(n):
    sum += (np.sqrt(p[i]) - np.sqrt(q[i]))**2
  result = (1.0 / np.sqrt(2.0)) * np.sqrt(sum)
  return result

def by_find_hellinger(data, clas):

    data = np.transpose(data)   # transpose for attribute selection

    # hellinger value
    h_value = []
    for i in range(len(data)):
        h_value.append(kumar_Hassebrook(data[i], clas)) # hellinger  value of attributes

    # Sort attribute by min
    H = h_value.copy()
    H.sort()

    # sorted index
    sort_index = []
    for i in range(len(H)):
        ind = h_value.index(H[i])     # index of sorted data
        sort_index.append(ind)
        h_value[ind] = np.inf   # set by max value to avoid repeated value confusion

    # sort Attributes by sorted index
    sorted_attr = []
    for i in range(len(sort_index)):
        sorted_attr.append(data[sort_index[i]])   # add attribute according to the sorted index
    return np.transpose(sorted_attr)    # transpose to get its original form
