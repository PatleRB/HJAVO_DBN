import numpy as np
import pandas as pd
from sklearn import preprocessing
from Main import DRN, Fusion1
import JAVO_LeNet.LeNet
import scipy.stats as stats
from dbn import main_dbn
from Main import Augmentation
def reducer_data(dts,fused_data):
    reader = pd.read_csv('fused_data.csv',header=None)  # read a file
    reader1 = pd.read_csv('target.csv',header=None)  # read a file

    print("\t\tBig data classification using JAVO.. ")
    return reader,reader1

def zscore(Data):
    zscores = stats.zscore(Data)
    return zscores


# mapper process: split the data to the size of mapper
def mapper(data, target, dts):
    feature_size = 10
    #apply preprocessing
    ######### zscore Normalization ###########
    pre_processed_data =zscore(data)
    fused_data,nn =[],[]

    for i in range(feature_size):
        ######### Feature Fusion (Hellinger Distance ###########
        sel_feature,n = Fusion1.feature_fusion(pre_processed_data[:,i], target, feature_size, i)
        fused_data.append(sel_feature)
        nn.append(n)

    Feature = Augmentation.augment(sel_feature)

    return Feature



# Reducer process
def reducer(fused_data,target,dts,tr_per,acc,sen,spe):

    reader,reader1=reducer_data(dts,fused_data)
    fused_data =np.array(reader)
    target1 =np.array(reader1)
    JAVO_LeNet.LeNet.classify(fused_data, target1, tr_per, acc, sen, spe)
    main_dbn.main(fused_data, target, tr_per, acc, sen, spe)

    return fused_data


# Feature main
def Mapper_phase(data, target, ms):
    feature = mapper(data, target, ms)
    return feature

def Map_Reducer(feat,target,lab,dts,ls,acc,sen,spe):
    ms = len(feat)
    print("\t >>Mapper Phase")
    sel_feat = Mapper_phase(feat,target,dts)
    print("\t >>Reducer Phase")
    reducer(sel_feat,lab,dts,ls,acc,sen,spe)
    return 0









